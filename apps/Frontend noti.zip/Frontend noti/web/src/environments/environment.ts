export const environment = {
  production: false,
  API_URL: 'http://192.168.9.15:3000',
  SOCKET_URL: 'http://192.168.9.15:3000'
};
